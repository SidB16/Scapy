"""
trackerjacker

Finds and tracks wifi devices through raw 802.11 monitoring
"""

__author__ = "Caleb Madrigal"
__email__ = "caleb.madrigal@gmail.com"
__license__ = "MIT"

from .version import __version__
