#!/bin/sh

# Python requirements


apt-get install scapy -y



