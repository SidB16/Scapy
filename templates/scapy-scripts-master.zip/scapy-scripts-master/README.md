## WiFi

http://stackoverflow.com/questions/10818661/scapy-retrieving-rssi-from-wifi-packets

http://hackoftheday.securitytube.net/2013/04/wi-fi-ssid-sniffer-in-12-lines-of.html

http://hackoftheday.securitytube.net/2013/03/wi-fi-sniffer-in-10-lines-of-python.html

http://scholarworks.sjsu.edu/cgi/viewcontent.cgi?article=1191&context=etd_projects

http://pen-testing.sans.org/blog/2011/10/13/special-request-wireless-client-sniffing-with-scapy

http://raidersec.blogspot.com/2013/01/wireless-deauth-attack-using-aireplay.html